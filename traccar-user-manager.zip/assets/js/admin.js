jQuery(document).ready(function ($) {
    // Add User Form Submission
    $('#addUserForm').on('submit', function (e) {
        e.preventDefault();
        var userData = {
            name: $('#newName').val(),
            email: $('#newEmail').val(),
            password: $('#newPassword').val(),
            phone: $('#newPhone').val(),
            deviceLimit: $('#newDeviceLimit').val(),
            expirationTime: $('#newExpirationTime').val(),
        };

        $.ajax({
            url: tamAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'tam_add_user',
                user_data: userData,
            },
            success: function (response) {
                if (response.success) {
                    alert('User added successfully!');
                    window.location.reload();
                } else {
                    alert('Failed to add user: ' + response.data);
                }
            },
            error: function (xhr, status, error) {
                console.error('AJAX Error:', error);
                alert('An error occurred while adding the user.');
            },
        });
    });

    // Delete User
    window.deleteUser = function (userId) {
        if (confirm('Are you sure you want to delete this user?')) {
            $.ajax({
                url: tamAjax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'tam_delete_user',
                    user_id: userId,
                },
                success: function (response) {
                    if (response.success) {
                        alert('User deleted successfully!');
                        window.location.reload();
                    } else {
                        alert('Failed to delete user: ' + response.data);
                    }
                },
                error: function (xhr, status, error) {
                    console.error('AJAX Error:', error);
                    alert('An error occurred while deleting the user.');
                },
            });
        }
    };

    // Edit User
    window.editUser = function (user) {
        // Populate modal with user data
        $('#editUserModal').find('#editUserId').val(user.id);
        $('#editUserModal').find('#editName').val(user.name);
        $('#editUserModal').find('#editEmail').val(user.email);
        $('#editUserModal').find('#editPhone').val(user.phone);
        $('#editUserModal').find('#editDeviceLimit').val(user.deviceLimit);
        $('#editUserModal').find('#editExpirationTime').val(user.expirationTime);
        $('#editUserModal').show();
    };

    // Edit User Form Submission
    $('#editUserForm').on('submit', function (e) {
        e.preventDefault();
        var userData = {
            id: $('#editUserId').val(),
            name: $('#editName').val(),
            email: $('#editEmail').val(),
            phone: $('#editPhone').val(),
            deviceLimit: $('#editDeviceLimit').val(),
            expirationTime: $('#editExpirationTime').val(),
        };

        $.ajax({
            url: tamAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'tam_update_user',
                user_data: userData,
            },
            success: function (response) {
                if (response.success) {
                    alert('User updated successfully!');
                    window.location.reload();
                } else {
                    alert('Failed to update user: ' + response.data);
                }
            },
            error: function (xhr, status, error) {
                console.error('AJAX Error:', error);
                alert('An error occurred while updating the user.');
            },
        });
    });

    // Close modals
    $('.close').click(function () {
        $('.modal').hide();
    });
});