<?php
/*
Plugin Name: Traccar User Manager WP Plugin
Plugin URI: #
Description: Manage Traccar users from WordPress admin dashboard
Version: 1.17
Author: Charlie Bolland
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define constants
define('TAM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TAM_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include necessary files
require_once TAM_PLUGIN_DIR . 'includes/menu.php';
require_once TAM_PLUGIN_DIR . 'includes/settings.php';
require_once TAM_PLUGIN_DIR . 'includes/user-management.php';
require_once TAM_PLUGIN_DIR . 'includes/ajax-handlers.php';
require_once TAM_PLUGIN_DIR . 'includes/admin-ui.php';
require_once TAM_PLUGIN_DIR . 'includes/helpers.php';

// Plugin activation hook
register_activation_hook(__FILE__, 'tam_activate');