<?php
// User Management Page
function tam_users_page() {
    // Fetch users from the API
    $users = get_traccar_users();

    // Handle errors in data fetching
    if (is_wp_error($users)) {
        echo '<div class="notice notice-error"><p>' . $users->get_error_message() . '</p></div>';
        return;
    }

    // Validate data before passing to the template
    if (!is_array($users)) {
        echo '<div class="notice notice-error"><p>Unexpected error: User data is not iterable.</p></div>';
        return;
    }

    // Include the User Management template
    include TAM_PLUGIN_DIR . 'templates/traccar-users.php';
}