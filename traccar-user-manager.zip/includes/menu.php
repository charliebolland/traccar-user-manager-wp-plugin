<?php
// Add admin menu
add_action('admin_menu', 'tam_admin_menu');

function tam_admin_menu() {
    // Add the main menu and submenus
    add_menu_page(
        'Traccar Users',               // Page title
        'Traccar Users',               // Menu title
        'manage_options',              // Capability
        'traccar-user-dashboard',      // Menu slug
        'tam_users_page',              // Callback function
        'dashicons-groups'             // Icon
    );

    add_submenu_page(
        'traccar-user-dashboard',      // Parent slug
        'Settings',                    // Page title
        'Settings',                    // Submenu title
        'manage_options',              // Capability
        'traccar-user-settings',       // Menu slug
        'tam_settings_page'            // Callback function
    );

    add_submenu_page(
        'traccar-user-dashboard',      // Parent slug
        'User Management',             // Page title
        'User Management',             // Submenu title
        'manage_options',              // Capability
        'traccar-user-dashboard',      // Menu slug
        'tam_users_page'               // Callback function
    );
}