<?php
// Function to fetch Traccar users
function get_traccar_users() {
    $server_url = get_option('tam_server_url');
    $username = get_option('tam_username');
    $password = get_option('tam_password');

    // Check if server settings are configured
    if (empty($server_url) || empty($username) || empty($password)) {
        error_log('[Traccar User Manager] Error: Server settings are not configured.');
        return new WP_Error('traccar_settings_error', 'Traccar server settings are not configured.');
    }

    // Fetch data from the API
    $response = wp_remote_get($server_url . '/api/users', array(
        'headers' => array(
            'Authorization' => 'Basic ' . base64_encode($username . ':' . $password),
        ),
    ));

    // Check for connection errors
    if (is_wp_error($response)) {
        error_log('[Traccar User Manager] API Error: ' . $response->get_error_message());
        return new WP_Error('traccar_connection_error', 'Failed to connect to the Traccar server.');
    }

    // Validate response status code
    $status_code = wp_remote_retrieve_response_code($response);
    if ($status_code !== 200) {
        error_log('[Traccar User Manager] API Error: Unexpected status code ' . $status_code);
        return new WP_Error('traccar_invalid_response', 'Unexpected response from Traccar server.');
    }

    // Decode the JSON response
    $body = wp_remote_retrieve_body($response);
    $users = json_decode($body);

    // Handle JSON decoding errors
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log('[Traccar User Manager] JSON Error: ' . json_last_error_msg());
        return new WP_Error('traccar_json_error', 'Failed to decode JSON response from Traccar server.');
    }

    // Ensure the response is an array
    if (!is_array($users)) {
        error_log('[Traccar User Manager] Error: Invalid response format.');
        return new WP_Error('traccar_invalid_format', 'Invalid response format from Traccar server.');
    }

    return $users;
}