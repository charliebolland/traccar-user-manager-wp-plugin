<?php
function tam_settings_page() {
    // Save settings if form is submitted
    if (isset($_POST['tam_save_settings'])) {
        update_option('tam_server_url', sanitize_text_field($_POST['tam_server_url']));
        update_option('tam_username', sanitize_text_field($_POST['tam_username']));
        update_option('tam_password', sanitize_text_field($_POST['tam_password']));
        echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
    }

    $server_url = get_option('tam_server_url');
    $username = get_option('tam_username');
    $password = get_option('tam_password');

    // Include the settings form
    include TAM_PLUGIN_DIR . 'templates/settings-page.php';
}

// Plugin activation hook
function tam_activate() {
    add_option('tam_server_url', '');
    add_option('tam_username', '');
    add_option('tam_password', '');
}