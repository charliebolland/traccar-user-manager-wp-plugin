<?php
// Add User AJAX Handler
add_action('wp_ajax_tam_add_user', 'tam_add_user');
function tam_add_user() {
    if (!isset($_POST['user_data'])) {
        wp_send_json_error('Missing user data.');
    }

    $user_data = $_POST['user_data'];
    $server_url = get_option('tam_server_url');
    $username = get_option('tam_username');
    $password = get_option('tam_password');

    $response = wp_remote_post($server_url . '/api/users', array(
        'headers' => array(
            'Authorization' => 'Basic ' . base64_encode($username . ':' . $password),
            'Content-Type' => 'application/json',
        ),
        'body' => json_encode($user_data),
    ));

    if (is_wp_error($response)) {
        wp_send_json_error('Failed to connect to Traccar server: ' . $response->get_error_message());
    } else {
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code === 200 || $status_code === 201) {
            wp_send_json_success('User added successfully.');
        } else {
            wp_send_json_error('Unexpected response from Traccar server: ' . $status_code);
        }
    }

    wp_die();
}

// Update User AJAX Handler
add_action('wp_ajax_tam_update_user', 'tam_update_user');
function tam_update_user() {
    if (!isset($_POST['user_data'])) {
        wp_send_json_error('Missing user data.');
    }

    $user_data = $_POST['user_data'];
    $user_id = intval($user_data['id']);
    $server_url = get_option('tam_server_url');
    $username = get_option('tam_username');
    $password = get_option('tam_password');

    $response = wp_remote_request($server_url . '/api/users/' . $user_id, array(
        'method' => 'PUT',
        'headers' => array(
            'Authorization' => 'Basic ' . base64_encode($username . ':' . $password),
            'Content-Type' => 'application/json',
        ),
        'body' => json_encode($user_data),
    ));

    if (is_wp_error($response)) {
        wp_send_json_error('Failed to connect to Traccar server: ' . $response->get_error_message());
    } else {
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code === 200) {
            wp_send_json_success('User updated successfully.');
        } else {
            wp_send_json_error('Unexpected response from Traccar server: ' . $status_code);
        }
    }

    wp_die();
}

// Delete User AJAX Handler
add_action('wp_ajax_tam_delete_user', 'tam_delete_user');
function tam_delete_user() {
    if (!isset($_POST['user_id'])) {
        wp_send_json_error('Missing user ID.');
    }

    $user_id = intval($_POST['user_id']);
    $server_url = get_option('tam_server_url');
    $username = get_option('tam_username');
    $password = get_option('tam_password');

    $response = wp_remote_request($server_url . '/api/users/' . $user_id, array(
        'method' => 'DELETE',
        'headers' => array(
            'Authorization' => 'Basic ' . base64_encode($username . ':' . $password),
        ),
    ));

    if (is_wp_error($response)) {
        wp_send_json_error('Failed to connect to Traccar server: ' . $response->get_error_message());
    } else {
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code === 200 || $status_code === 204) {
            wp_send_json_success('User deleted successfully.');
        } else {
            wp_send_json_error('Unexpected response from Traccar server: ' . $status_code);
        }
    }

    wp_die();
}