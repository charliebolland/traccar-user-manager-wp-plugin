<div class="wrap">
    <h1>Traccar API Manager Settings</h1>
    <form method="post">
        <table class="form-table">
            <tr>
                <th>Server URL</th>
                <td><input type="url" name="tam_server_url" value="<?php echo esc_attr($server_url); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th>Username</th>
                <td><input type="text" name="tam_username" value="<?php echo esc_attr($username); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th>Password</th>
                <td><input type="password" name="tam_password" value="<?php echo esc_attr($password); ?>" class="regular-text"></td>
            </tr>
        </table>
        <p class="submit">
            <input type="submit" name="tam_save_settings" class="button-primary" value="Save Settings">
        </p>
    </form>
</div>