<h1>Traccar Users</h1>
<table class="wp-list-table widefat fixed striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Account Status</th>
            <th>Device Limit</th>
            <th>Expiration Time</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?php echo esc_html($user->id); ?></td>
            <td><?php echo esc_html($user->name); ?></td>
            <td><?php echo esc_html($user->email); ?></td>
            <td><?php echo $user->disabled ? 'Disabled' : 'Active'; ?></td>
            <td><?php echo esc_html($user->deviceLimit); ?></td>
            <td><?php echo $user->expirationTime ? esc_html($user->expirationTime) : 'Not Set'; ?></td>
            <td>
                <button class="button" onclick="editUser(<?php echo esc_js(json_encode($user)); ?>)">Edit</button>
                <button class="button" onclick="deleteUser(<?php echo esc_js($user->id); ?>)">Delete</button>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>