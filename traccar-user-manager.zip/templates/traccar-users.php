<h1>Traccar Users</h1>

<!-- Add User Button -->
<button class="button button-primary add-user-button" onclick="showAddUserModal()">Add User</button>

<!-- User Table -->
<table class="wp-list-table widefat fixed striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Account Status</th>
            <th>Device Limit</th>
            <th>Expiration Time</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($users)): ?>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><?php echo esc_html($user->id); ?></td>
                <td><?php echo esc_html($user->name); ?></td>
                <td><?php echo esc_html($user->email); ?></td>
                <td>
                    <?php echo $user->disabled
                        ? '<span style="color:red">Disabled</span>'
                        : '<span style="color:green">Active</span>'; ?>
                </td>
                <td><?php echo esc_html($user->deviceLimit); ?></td>
                <td>
                    <?php
                    if ($user->expirationTime) {
                        $expiry = new DateTime($user->expirationTime);
                        $now = new DateTime();
                        $interval = $now->diff($expiry);
                        $days = $interval->days;
                        $color = $expiry < $now ? 'red' : ($days <= 14 ? 'orange' : 'green');
                        echo '<span style="color:' . $color . '">' . $expiry->format('Y-m-d H:i:s') . '</span>';
                    } else {
                        echo '<span style="color:red">Not set</span>';
                    }
                    ?>
                </td>
                <td>
                    <button class="button" onclick="editUser(<?php echo esc_js(json_encode($user)); ?>)">Edit</button>
                    <button class="button" onclick="deleteUser(<?php echo esc_js($user->id); ?>)">Delete</button>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="7">No users found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>